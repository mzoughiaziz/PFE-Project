@extends('layouts.app')

@section('content')
    <div class="header bg-gradient-primary pb-8 pt-5 pt-md-8">

    </div>
    <div class="container-fluid mt--7">
        <div class="row">
            <div class="col">
                <div class="card shadow">
                    <div class="card-header border-0">
                        <div class="row align-items-center">
                            <div class="col-8">
                                <h3 class="mb-0">Office Expenses</h3>
                            </div>
                            <div class="col-4 text-right">
                                {{-- lunch modal button --}}
                                <button type="button" class="btn btn-sm btn-primary" data-toggle="modal"
                                    data-target="#modal-form">
                                    Create new
                                </button>
                            </div>
                        </div>
                    </div>

                    <div class="col-12">
                    </div>

                    <div class="table-responsive">
                        <table class="table align-items-center table-flush">
                            <thead class="thead-light">
                                <tr>
                                    <th scope="col">ID</th>
                                    <th scope="col">Name</th>
                                    <th scope="col">Amount</th>
                                    <th scope="col">Type</th>
                                    <th scope="col">Associates</th>
                                    <th scope="col">Description</th>
                                    <th scope="col">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($frais as $frai)
                                <tr>
                                        <td> {{$frai->id}} </td>
                                        <td> {{$frai->name}} </td>
                                        <td> {{$frai->amount}} </td>
                                        <td> {{$frai->type}} </td>
                                        <td> {{$frai->user_id}} </td>
                                        <td> {{$frai->descreption}} </td>
                                </tr>
                                @endforeach
                             
                            </tbody>
                        </table>
                    </div>

                </div>
            </div>
        </div>
    </div>
    </div>
    <div class="col-md-4">

        <div class="modal fade" id="modal-form" tabindex="-1" role="dialog" aria-labelledby="modal-form" aria-hidden="true">
            <div class="modal-dialog modal- modal-dialog-centered modal-lg" role="document">
                <div class="modal-content">

                    <div class="modal-body p-0">

                        {{-- Modal --}}

                        <div class="card bg-secondary border-0 mb-0">

                            <div class="card-body px-lg-5 py-lg-5">
                                <div class="text-center text-muted mb-4">
                                    <h2>Create new expense</h2>
                                </div>
                                <form role="form">
                                    <div class="mb-3">
                                        <div class="input-group">
                                            <input class="form-control" placeholder="Name" type="text">
                                        </div>
                                    </div>

                                    <div class="mb-3">
                                        <div class="input-group">
                                            <input class="form-control" placeholder="Amount" type="number">
                                            <input class="form-control" placeholder="Client name" type="text">
                                            <input class="form-control" placeholder="Type (Cloud services, Electronics...)" type="text">
                                        </div>
                                    </div>

                                    <div class="mb-3">
                                        <div class="input-group">
                                            <input class="form-control" placeholder="Description" type="text">
                                        </div>
                                    </div>

                                    <div class="text-center">
                                        <button type="button" class="btn btn-primary ">Create</button>
                                    </div>

                                </form>
                            </div>
                        </div>


                        {{-- @include('layouts.footers.auth') --}}

                    @endsection

                    @push('js')
                        <script src="{{ asset('argon') }}/vendor/chart.js/dist/Chart.min.js"></script>
                        <script src="{{ asset('argon') }}/vendor/chart.js/dist/Chart.extension.js"></script>
                    @endpush
