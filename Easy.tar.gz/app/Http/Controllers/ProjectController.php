<?php

namespace App\Http\Controllers;

use App\Models\client;
use App\Models\project;
use App\Models\User;


use Illuminate\Http\Request;

class ProjectController extends Controller
{
    public function index()
    {
    $projects = project::get();

        foreach($projects as $project){
            $project->user_id = User::where('id',$project->user_id)->value('firstname');
            $project->client_id = client::where('id',$project->client_id)->value('firstname');

        }

    return view('project.index' , ["projects" => $projects]);
    }
}
