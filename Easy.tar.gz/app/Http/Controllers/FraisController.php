<?php

namespace App\Http\Controllers;
use App\Models\frais;
use App\Models\User;


use Illuminate\Http\Request;

class FraisController extends Controller
{

    public function index()
    {
    $frais = frais::get();

    foreach($frais as $frai){
        $frai->user_id = User::where('id',$frai->user_id)->value('firstname');

    }


    return view('frais_office.index' , ["frais" => $frais]);
    }
}
