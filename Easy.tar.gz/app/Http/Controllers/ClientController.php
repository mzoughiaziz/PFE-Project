<?php

namespace App\Http\Controllers;

use App\Models\client;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class ClientController extends Controller
{
    public function index()
    {

        $clients = client::get();
        return view('clients.index' , ["clients" => $clients]);
    }


    public function store(request $req)
    {

        if(auth()->user()->role == 1) {

        $client = new client ; 
        $client->id = Str::uuid()->toString();
        $client->firstname = $req->firstname ;
        $client->lastname = $req->lastname ;
        $client->cin = $req->cin ;
        $client->passport = $req->passport ;
        $client->marital_status = $req->marital_status ;
        $client->gender = $req->gender ;
        $client->bday = $req->bday ;
        $client->email = $req->email ;
        $client->job = $req->job ;
        $client->adress = $req->adress ;
        $client->save();
        return back()->withStatus(__('Client added successfully'));
    }
    else {
        abort(403);
    }
    }
}
