<?php

namespace App\Http\Controllers;

use App\Models\project;
use App\Models\recette;
use App\Models\User;


use Illuminate\Http\Request;

class RecetteController extends Controller
{
    public function index()
    {
    $recettes = recette::get();
    foreach ($recettes as $recette){
        $recette->user_id = User::where('id',$recette->user_id)->value('firstname');
        $recette->project_id = project::where('id',$recette->project_id)->value('name');
    }
    return view('res_office.index' , ["recettes" => $recettes]);
    }
}
