<?php $__env->startSection('content'); ?>
<div class="header bg-gradient-primary pb-8 pt-5 pt-md-8">
 
    </div>
    <div class="container-fluid mt--7">
        <div class="row">
            <div class="col">
                <div class="card shadow">
                    <div class="card-header border-0">
                        <div class="row align-items-center">
                            <div class="col-8">
                                <h3 class="mb-0">People</h3>
                            </div>
                            <div class="col-4 text-right">
                                
                                <button type="button" class="btn btn-sm btn-primary" data-toggle="modal" data-target="#modal-form">
                                    Create new
                                </button>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-12">
                    </div>
    
                    <div class="table-responsive">
                        <table class="table align-items-center table-flush">
                            <thead class="thead-light">
                                <tr>
                                <th scope="col">Id</th>
                                    <th scope="col">Name</th>
                                    <th scope="col">Contact </th>
                                    <th scope="col">Data</th>
                                    <th scope="col">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                                                    <tr>
                                        <td>Admin Admin</td>
                                        <td>
                                            <a href="mailto:admin@argon.com">admin@argon.com</a>
                                        </td>
                                        <td>TEST</td>
                                        <td>12/02/2020 11:00</td>
                                        <td class="text-right">
                                            <div class="dropdown">
                                                <a class="btn btn-sm btn-icon-only text-light" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                    <i class="fas fa-ellipsis-v"></i>
                                                </a>
                                                <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                                                                                            <a class="dropdown-item" href="">Edit</a>
                                                                                                    </div>
                                            </div>
                                        </td>
                                    </tr>
                                                            </tbody>
                        </table>
                    </div>
                
                </div>
            </div>
        </div>
    </div>
    </div>

    <div class="col-md-4">
       
        <div class="modal fade" id="modal-form" tabindex="-1" role="dialog" aria-labelledby="modal-form" aria-hidden="true">
      <div class="modal-dialog modal- modal-dialog-centered modal-lg" role="document">
          <div class="modal-content">
              
              <div class="modal-body p-0">
                  
  
  
  <div class="card bg-secondary border-0 mb-0">
     
      <div class="card-body px-lg-5 py-lg-5">
          <div class="text-muted mb-4">
            REGISTRATION OF PEOPLE
          </div>
          <form action="?pg=pessoas" method="post" enctype="multipart/form-data" name="FORMULARIO_PESSOAS" id="pessoas_FORMULARIO_PESSOAS" onsubmit="FrmSend(); return false;">
								<!--Data de Hoje-->
				<input name="id" type="hidden" value="1176347">
				<!--Input Hidden-->
				<input id="moduloDestino" type="hidden" value="pessoas">
				<!--Input Hidden-->
				<input name="acao" type="hidden" value="updatebd">
				<!--Input Hidden-->
				<input type="hidden" id="ajax_processo_pessoa_lista" value="0">
				<!--Input Hidden-->
				<input type="hidden" id="ajax_agenda_pessoa_lista" value="0">
				<!--Input Hidden-->
				<input type="hidden" id="ajax_contrato_pessoa_lista" value="0">
				<!--Input Hidden-->
				<input type="hidden" id="ajax_receitas_pessoa_lista" value="0">
				<!--Input Hidden-->
				<input type="hidden" id="ajax_despesas_pessoa_lista" value="0">
				<!--Input Hidden-->
				<input type="hidden" id="ajax_jobs_pessoa_lista" value="0">
				<!--Input Hidden-->
				<input type="hidden" id="ajax_documentos_pessoa_lista" value="0">
				<!--Input Hidden-->
				<input type="hidden" id="ajax_oportunidades_pessoa_lista" value="0">
				<!--Input Hidden-->
				<div class="boxJanela__item-minimize" style="padding-bottom: 40px;">
					<div class="row">
												<div class="col-md-2">
							<div class="boxInput">
								<label><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">id</font></font></label>
								<input type="text" name="id_agend" readonly="readonly" value="1176347" disabled="">
							</div>
						</div>
						<div class="col-md-4" style="min-width: 10% !important;">
							<div class="boxInput">
								<label id="label_nome_pessoa"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">PERSON NAME</font></font><span style="color:#ff0000;position: absolute;transform: scale(1.5);padding: 0px 5px"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> * </font></font></span> </label>
								<label id="label_razao_social" style="display: none;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">CORPORATE NAME</font></font><span style="color:#ff0000;position: absolute;transform: scale(1.5);padding: 0px 5px"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> * </font></font></span></label>
								<input placeholder="" class="input" name="nome" id="pessoas_nome" type="text" value="" size="40">
							</div>
						</div>
						<div class="col-md-3">
							<div class="boxInput">
								<label id="label_apelido"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Surname</font></font></label>
								<label id="label_fantasia" style="display: none;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Fantasy name</font></font></label>
								<input name="apelido_obrigatorio" id="apelido_obrigatorio" type="hidden" value="0">
								<input placeholder="" name="apelido" id="apelido" type="text" class="input" value="" size="32">
							</div>
						</div>
						<div class="col-md-3">
							<div class="boxInput boxInput--withBtn">
								<label><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">CONTACT PERSON</font></font></label>
								<div>
									<input placeholder="" name="contato" id="pessoas_contato" type="text" class="input ui-autocomplete-input" value="" size="32" autocomplete="off">
									<!-- <a onclick="ativa_modal(CADASTRO_pessoas2); cadastrar_pessoa2('pessoa'); mudarJanelaPessoa2(); ">
                    <i class="fa fa-plus-square"></i>
                  </a> -->
								</div>
							</div>
						</div>
					</div>
					<div class="row">
												<div class="col-md-2">
							<div class="boxInput"> 
								<label><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">NATURE</font></font><span style="color:#ff0000;position: absolute;transform: scale(1.5);padding: 0px 5px"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> * </font></font></span></label>
								<select name="tipo_pessoa" id="fisica_juridica" class="input">
									<option value="fisica"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Physics</font></font></option>
									<option value="juridica"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Legal</font></font></option>
								</select>
							</div>
						</div>
						<div class="col-md-2" id="div_cpf">
							<div class="boxInput">
								<label><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">CPF</font></font><span id="label_cpf" style="display: none;color:#ff0000;position: absolute;transform: scale(1.5);padding: 0px 5px"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> * </font></font></span></label>
								<input placeholder="" name="cpf" id="pessoas_cpf" type="text" class="input" maxlength="14" value="" size="18" autocomplete="off">
							</div>
						</div>
						<div class="col-md-3" id="div_cnpj" style="display: none;">
							<div class="boxInput">
								<label><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">CNPJ</font></font><span id="label_cnpj" style="display: none;color:#ff0000;position: absolute;transform: scale(1.5);padding: 0px 5px"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> * </font></font></span></label>
								<input placeholder="" name="cnpj" id="pessoas_cnpj" type="text" class="input" maxlength="18" value="" size="18" autocomplete="off">
							</div>
						</div>
						<div class="col-md-2">
							<div class="boxInput">
								<label><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">ID/IE</font></font></label>
								<input name="rg" id="rg" type="text" placeholder="" class="input" onblur="this.className='input';" onfocus="this.className='inputon';" value="" size="18">
							</div>
						</div>
						<div class="col-md-2" id="div_rg_orgao">
							<div class="boxInput">
								<label><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">EXPERT ORGAN</font></font></label>
								<input name="rg_orgao" id="rg_orgao" type="text" placeholder="" class="input" value="" size="6">
							</div>
						</div>
						<div class="col-md-4" id="div_pessoas_email" style="min-width: 10% !important;">
							<div class="boxInput">
								<label><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">MAIN EMAIL</font></font></label>
								<input placeholder="" name="email" id="pessoas_email" type="text" class="input" value="" size="22">
							</div>
						</div>
					</div>
					<div class="row">
												<div class="col-md-2" id="div_cnh" style="min-width: 10% !important;">
							<div class="boxInput">
								<label><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">CNH</font></font></label>
								<input placeholder="" name="cnh" id="cnh" type="text" class="input" value="" size="22">
							</div>
						</div>
						<div class="col-md-2" style="min-width: 10% !important;">
							<div class="boxInput">
								<label><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">PARENTS</font></font></label>
								<input placeholder="" name="pais" id="pessoas_pais" type="text" class="input ui-autocomplete-input" value="" size="22" autocomplete="off">
							</div>
						</div>
						<div class="col-md-2">
							<div class="boxInput">
								<label><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">TELEPHONE</font></font></label>
								<input placeholder="" name="telefone" id="pessoas_telefone" type="text" class="input" value="" maxlength="15" autocomplete="off">
							</div>
						</div>
						<div class="col-md-2">
							<div class="boxInput">
								<label><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">PHONE 2</font></font></label>
								<input placeholder="" name="telefone2" id="pessoas_telefone2" type="text" class="input" value="" maxlength="15" autocomplete="off">
							</div>
						</div>
						<div class="col-md-2">
							<div class="boxInput">
								<label><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">CELL PHONE</font></font><i class="icon-whatsapp"></i></label>
								<input placeholder="" name="celular" id="pessoas_celular" type="text" class="input" value="" maxlength="15" autocomplete="off">
							</div>
						</div>
						<div class="col-md-2">
							<div class="boxInput">
								<label><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">CELL PHONE 2</font></font></label>
								<input placeholder="" name="celular2" id="pessoas_celular2" type="text" class="input" value="" maxlength="15" autocomplete="off">
							</div>
						</div>
					</div>
					<div class="row">
												<div class="col-md-3">
							<div class="boxInput">
								<label id="label_cep"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Zip Code </font></font><a href="http://www.buscacep.correios.com.br/" target="_blank"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Don't know the zip code?</font></font></a></label>
								<input placeholder="" name="cep" id="pessoas_cep" type="text" class="input" maxlength="9" value="" size="7" autocomplete="off">
							</div>
						</div>
						<div class="col-md-3">
							<div class="boxInput">
								<label><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">ADDRESS</font></font></label>
								<input placeholder="" name="endereco" id="pessoas_endereco" type="text" class="input" value="" size="28">
							</div>
						</div>
						<div class="col-md-2">
							<div class="boxInput">
								<label><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">NUMBER</font></font></label>
								<input placeholder="" name="numero" id="pessoas_numero" type="number" class="input" value="" size="4">
							</div>
						</div>
						<div class="col-md-4" style="min-width:20% !important">
							<div class="boxInput">
								<label><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">COMPLEMENT</font></font></label>
								<input placeholder="" name="complemento" id="pessoas_complemento" type="text" class="input" value="" size="8">
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-3"><div class="boxInput"><label><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">OAB No.</font></font></label><input name="campo_personalizado_1" id="campo_personalizado_1" data-id="1" type="number" class="input campos_personalizado" value=""></div></div><div class="col-md-3"><div class="boxInput"><label><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">OAB No.</font></font></label><input name="campo_personalizado_10" id="campo_personalizado_10" data-id="10" type="number" class="input campos_personalizado" value=""></div></div><div class="col-md-3"><div class="boxInput"><label><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">OAB No.</font></font></label><input name="campo_personalizado_19" id="campo_personalizado_19" data-id="19" type="number" class="input campos_personalizado" value=""></div></div><div class="col-md-3"><div class="boxInput"><label><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">OAB No.</font></font></label><input name="campo_personalizado_28" id="campo_personalizado_28" data-id="28" type="number" class="input campos_personalizado" value=""></div></div><div class="col-md-3"><div class="boxInput"><label><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">OAB No.</font></font></label><input name="campo_personalizado_37" id="campo_personalizado_37" data-id="37" type="number" class="input campos_personalizado" value=""></div></div><div class="col-md-3"><div class="boxInput"><label><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">OAB No.</font></font></label><input name="campo_personalizado_46" id="campo_personalizado_46" data-id="46" type="number" class="input campos_personalizado" value=""></div></div><div class="col-md-3"><div class="boxInput"><label><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">OAB No.</font></font></label><input name="campo_personalizado_55" id="campo_personalizado_55" data-id="55" type="number" class="input campos_personalizado" value=""></div></div><div class="col-md-3"><div class="boxInput"><label><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">OAB No.</font></font></label><input name="campo_personalizado_64" id="campo_personalizado_64" data-id="64" type="number" class="input campos_personalizado" value=""></div></div><div class="col-md-3"><div class="boxInput"><label><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">OAB No.</font></font></label><input name="campo_personalizado_73" id="campo_personalizado_73" data-id="73" type="number" class="input campos_personalizado" value=""></div></div><div class="col-md-3"><div class="boxInput"><label><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">OAB No.</font></font></label><input name="campo_personalizado_82" id="campo_personalizado_82" data-id="82" type="number" class="input campos_personalizado" value=""></div></div>						<div class="col-md-3">
							<div class="boxInput">
								<label><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">state</font></font></label>
								<select id="pessoas_estado" name="pessoas_estado" onchange="mudar()">
									<option value=""><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Select the State</font></font></option>
									<option value="AC"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">B.C</font></font></option>
									<option value="AL"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">AL</font></font></option>
									<option value="AP"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">AP</font></font></option>
									<option value="AM"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">AM</font></font></option>
									<option value="BA"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">BA</font></font></option>
									<option value="CE"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">EC</font></font></option>
									<option value="DF"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">DF</font></font></option>
									<option value="ES"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">ES</font></font></option>
									<option value="GO"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">GO</font></font></option>
									<option value="MA"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">BAD</font></font></option>
									<option value="MT"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">MT</font></font></option>
									<option value="MS"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">MS</font></font></option>
									<option value="MG"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">MG</font></font></option>
									<option value="PA"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">PAN</font></font></option>
									<option value="PB"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">PB</font></font></option>
									<option value="PR"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">PR</font></font></option>
									<option value="PE"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">FOOT</font></font></option>
									<option value="PI"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">PI</font></font></option>
									<option value="RJ"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">RJ</font></font></option>
									<option value="RN"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">RN</font></font></option>
									<option value="RS"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">LOL</font></font></option>
									<option value="RO"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">RO</font></font></option>
									<option value="RR"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">RR</font></font></option>
									<option value="SC"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">SC</font></font></option>
									<option value="SP"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">SP</font></font></option>
									<option value="SE"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">IF</font></font></option>
									<option value="TO"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">TO</font></font></option>
								</select>
							</div>
						</div>
						<div class="col-md-3">
							<div class="boxInput">
								<label><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">CITY</font></font></label>
								<select name="id_cidade" id="pessoas_id_cidade">
									<option value=""></option>
								</select>
							</div>
						</div>
						<div class="col-md-3">
							<div class="boxInput">
								<label><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">DISTRICT</font></font></label>
								<input placeholder="" type="text" name="bairro" id="pessoas_bairro" size="15" value="">
							</div>
						</div>
						<div class="col-md-3">
							<div class="boxInput">
								<label><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">WEB SITE</font></font></label>
								<input placeholder="" name="website" id="pessoas_website" type="text" value="" size="22">
							</div>
						</div>
					</div>
										<div class="row">
						<div class="col-md-12">
							<div class="boxInput">
								<table width="100%" border="0" cellpadding="2" cellspacing="0">
																		<tbody><tr>
										<td><input name="tipo_cad[]" type="checkbox" id="tipo_cad[1]" class="tipoCad" value="|cliente"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Client</font></font></td>
										<td><input name="tipo_cad[]" type="checkbox" id="tipo_cad[2]" value="|fornecedor"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Provider</font></font></td>
										<td><input name="tipo_cad[]" type="checkbox" id="tipo_cad[3]" class="tipoCad" value="|parte_adversa"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Adverse Party</font></font></td>
										<td><input name="tipo_cad[]" type="checkbox" id="tipo_cad[4]" value="|adv_parte"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Adverse Lawyer</font></font></td>
										<td><input name="tipo_cad[]" type="checkbox" id="tipo_cad[5]" value="|lead"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Lead</font></font></td>
									</tr>
									<tr>
										<td><input name="tipo_cad[]" type="checkbox" id="tipo_cad[6]" value="|correspondente"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Corresponding</font></font></td>
										<td><input name="tipo_cad[]" type="checkbox" id="tipo_cad[7]" value="|juizo"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Judge</font></font></td>
										<td><input name="tipo_cad[]" type="checkbox" id="tipo_cad[8]" value="|outros"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Others</font></font></td>
										<td><input name="tipo_cad[]" type="checkbox" id="tipo_cad[9]" value="|colaborador"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">collaborator</font></font></td>
									</tr>
								</tbody></table>
							</div>
						</div>
					</div>
					<div class="boxJanela__item-expand_pessoas opened">
						<div class="row" id="div_numeros">
							<div class="col-md-2">
								<div class="boxInput">
									<label><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">NIS No.</font></font></label>
									<input name="nis" id="nis" type="text" placeholder="" class="input" value="" size="17">
								</div>
							</div>
							<div class="col-md-2">
								<div class="boxInput">
									<label><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">PIS No.</font></font></label>
									<input name="pis" id="pis" type="text" placeholder="" class="input" value="" size="17">
								</div>
							</div>
							<div class="col-md-2">
								<div class="boxInput">
									<label><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">CTPS No.</font></font></label>
									<input name="ctps" id="ctps" type="text" placeholder="" class="input" value="" size="17">
								</div>
							</div>
							<div class="col-md-3">
								<div class="boxInput">
									<label><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">MOTHER'S NAME</font></font></label>
									<input name="nome_mae" id="nome_mae" type="text" placeholder="" class="input" value="" size="28">
								</div>
							</div>
							<div class="col-md-3">
								<div class="boxInput">
									<label><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">FATHER'S NAME</font></font></label>
									<input name="nome_pai" id="nome_pai" type="text" placeholder="" class="input" value="" size="28">
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-2" id="div_insc_estadual" style="display: none;">
								<div class="boxInput">
									<label><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">STATE REGISTRATION</font></font></label>
									<input name="inscricao_estadual" id="inscricao_estadual" type="text" placeholder="" class="input" value="">
								</div>
							</div>
							<div class="col-md-2" id="div_insc_municipal" style="display: none;">
								<div class="boxInput">
									<label style="font-size: 11px; padding-top: 7px;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">MUNICIPAL REGISTRATION</font></font></label>
									<input name="inscricao_municipal" id="inscricao_municipal" type="text" placeholder="" class="input" value="">
								</div>
							</div>
							<div class="col-md-3">
								<div class="boxInput boxInput--withBtn">
									<label><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">LINKED PERSON</font></font></label>
									<div>
										<input placeholder="" name="pessoas_vinculada" id="pessoas_vinculada" type="text" class="input ui-autocomplete-input" value="" size="32" autocomplete="off">
										<!-- <a onclick="ativa_modal(CADASTRO_pessoas2); cadastrar_pessoa2('pessoa'); mudarJanelaPessoa2(); ">
                      <i class="fa fa-plus-square"></i>
                    </a> -->
									</div>
								</div>
							</div>
							<div class="col-md-3" id="divProfissao">
								<div class="boxInput">
									<label><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">PROFESSION</font></font></label>
									<input placeholder="" name="profissao" id="profissao" type="text" value="" size="10" class="ui-autocomplete-input" autocomplete="off">
								</div>
							</div>
							<div class="col-md-3" id="div_nacionalidade">
								<div class="boxInput">
									<label><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">NATIONALITY</font></font></label>
									<input placeholder="" name="nacionalidade" id="nacionalidade" type="text" value="" size="17">
								</div>
							</div>
							<div class="col-md-3" id="div_aniversario">
								<div class="boxInput">
									<label style="" id="label_nascimento"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">BIRTH DATE</font></font></label>
									<label style="display:none" id="label_data_abertura"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">OPENING DATE</font></font></label>
									<input title="Birthday" name="aniversario" id="aniversario" type="text" placeholder="" value="" size="10" onclick="displayCalendar(this,'dd/mm/yyyy',this)" maxlength="10" autocomplete="off">
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-2" id="div_genero">
								<div class="boxInput">
									<label><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">GENDER</font></font></label>
									<select name="genero" id="genero" class="input" onblur="this.className='input';" onfocus="this.className='inputon';">
										<option value=""><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Gender</font></font></option>
										<option value="feminino"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Feminine</font></font></option>
										<option value="masculino"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Male</font></font></option>
									</select>
								</div>
							</div>
							<div class="col-md-2" id="div_estado_civil">
								<div class="boxInput">
									<label><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">MARITAL STATUS</font></font></label>
									<select name="estado_civil" id="estado_civil" class="input" onblur="this.className='input';" onfocus="this.className='inputon';">
										<option value=""><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Marital status</font></font></option>
										<option value="solteiro"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Single</font></font></option>
										<option value="casado"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Married</font></font></option>
										<option value="divorciado"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Divorced</font></font></option>
										<option value="viuvo"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Widowed</font></font></option>
										<option value="uniaoestavel"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Stable union</font></font></option>
										<option value="falecido"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">deceased</font></font></option>
									</select>
								</div>
							</div>
							<div class="col-md-2">
								<div class="boxInput">
									<label><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">STATUS</font></font></label>
									<select name="status" id="pessoas_status" class="input">
										<option value="Ativo"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Active</font></font></option>
										<option value="Inativo"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Inactive</font></font></option>
										<option value="Bloqueado"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Blocked</font></font></option>
										<option value="Devedor"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Debtor</font></font></option>
									</select>
								</div>
							</div>
							<div class="col-md-3">
								<div class="boxInput">
									<label><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">PAYMENT</font></font></label>
									<select name="fiscal" id="fiscal" class="input" onblur="this.className='input';" onfocus="this.className='inputon';">
										<option value=""><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Payment Type</font></font></option>
										<option value="fiscal"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Supervisor</font></font></option>
										<option value="naofiscal"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Non-tax</font></font></option>
									</select>
								</div>
							</div>
							<div class="col-md-3" style="min-width: 10% !important;">
								<div class="boxInput">
									<label><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">SECONDARY EMAIL</font></font></label>
									<input placeholder="" name="email2" id="pessoas_email2" type="text" class="input" value="" size="22">
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-2">
								<div style="padding-top:28px" class="boxInput">
									<input name="isento_impostos" type="checkbox" id="isento_impostos"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Duty-free
								</font></font></div>
							</div>
							<div class="col-md-2" id="col_retencao_iss">
								<div style="padding-top:28px" class="boxInput">
									<input type="checkbox" id="retencao_iss" name="camposRetencao[]"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">ISS withholding
								</font></font></div>
							</div>

							<div class="col-md-2" id="col_retencao_irrf">
								<div style="padding-top:28px" class="boxInput">
									<input type="checkbox" id="retencao_irrf" name="camposRetencao[]"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">IRRF withholding
								</font></font></div>
							</div>

							<div class="col-md-2" id="col_retencao_pis">
								<div style="padding-top:28px" class="boxInput">
									<input type="checkbox" id="retencao_pis" name="camposRetencao[]"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">PIS retention
								</font></font></div>
							</div>

							<div class="col-md-2" id="col_retencao_confins">
								<div style="padding-top:28px" class="boxInput">
									<input type="checkbox" id="retencao_confins" name="camposRetencao[]"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Cofins Retention
								</font></font></div>
							</div>

							<div class="col-md-2" id="col_retencao_csll">
								<div style="padding-top:28px" class="boxInput">
									<input type="checkbox" id="retencao_csll" name="camposRetencao[]"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">CSLL retention
								</font></font></div>
							</div>

						</div>
						<div class="row">
							<div class="col-md-12">
								<div class="boxInput">
									<label><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">SEGMENTS:</font></font></label>
									<table width="100%" border="0" cellpadding="2" cellspacing="0">
																				<tbody><tr>
											<td><input name="tipo[]" type="checkbox" id="tipo[8]" value="|8"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Administrative</font></font></td><td><input name="tipo[]" type="checkbox" id="tipo[36]" value="|36"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Agrarian</font></font></td><td><input name="tipo[]" type="checkbox" id="tipo[1]" value="|1"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Environmental</font></font></td><td><input name="tipo[]" type="checkbox" id="tipo[14]" value="|14"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">International Arbitration</font></font></td></tr><tr><td><input name="tipo[]" type="checkbox" id="tipo[35]" value="|35"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Bank officer</font></font></td><td><input name="tipo[]" type="checkbox" id="tipo[2]" value="|2"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">civil</font></font></td><td><input name="tipo[]" type="checkbox" id="tipo[15]" value="|15"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Commercial</font></font></td><td><input name="tipo[]" type="checkbox" id="tipo[38]" value="|38"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">condominium</font></font></td></tr><tr><td><input name="tipo[]" type="checkbox" id="tipo[3]" value="|3"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Constitutional</font></font></td><td><input name="tipo[]" type="checkbox" id="tipo[31]" value="|31"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Advisory</font></font></td><td><input name="tipo[]" type="checkbox" id="tipo[12]" value="|12"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Consumer</font></font></td><td><input name="tipo[]" type="checkbox" id="tipo[25]" value="|25"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Contracts and Compliance</font></font></td></tr><tr><td><input name="tipo[]" type="checkbox" id="tipo[26]" value="|26"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">sporty</font></font></td><td><input name="tipo[]" type="checkbox" id="tipo[13]" value="|13"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Digital and Computer</font></font></td><td><input name="tipo[]" type="checkbox" id="tipo[33]" value="|33"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">DPO</font></font></td><td><input name="tipo[]" type="checkbox" id="tipo[28]" value="|28"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Educational</font></font></td></tr><tr><td><input name="tipo[]" type="checkbox" id="tipo[9]" value="|9"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Electoral</font></font></td><td><input name="tipo[]" type="checkbox" id="tipo[11]" value="|11"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Business</font></font></td><td><input name="tipo[]" type="checkbox" id="tipo[23]" value="|23"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Expropriation - Possessions</font></font></td><td><input name="tipo[]" type="checkbox" id="tipo[17]" value="|17"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Extrajudicial - Mediation - Arbitration</font></font></td></tr><tr><td><input name="tipo[]" type="checkbox" id="tipo[10]" value="|10"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Family and Successions</font></font></td><td><input name="tipo[]" type="checkbox" id="tipo[16]" value="|16"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">real estate</font></font></td><td><input name="tipo[]" type="checkbox" id="tipo[22]" value="|22"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">International</font></font></td><td><input name="tipo[]" type="checkbox" id="tipo[19]" value="|19"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Military</font></font></td></tr><tr><td><input name="tipo[]" type="checkbox" id="tipo[20]" value="|20"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Obligations and Contracts</font></font></td><td><input name="tipo[]" type="checkbox" id="tipo[4]" value="|4"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Criminal-Criminal</font></font></td><td><input name="tipo[]" type="checkbox" id="tipo[5]" value="|5"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">social security</font></font></td><td><input name="tipo[]" type="checkbox" id="tipo[32]" value="|32"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Intellectual property</font></font></td></tr><tr><td><input name="tipo[]" type="checkbox" id="tipo[29]" value="|29"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">data protection</font></font></td><td><input name="tipo[]" type="checkbox" id="tipo[18]" value="|18"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Judicial Reorganization</font></font></td><td><input name="tipo[]" type="checkbox" id="tipo[34]" value="|34"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">health</font></font></td><td><input name="tipo[]" type="checkbox" id="tipo[24]" value="|24"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Corporate</font></font></td></tr><tr><td><input name="tipo[]" type="checkbox" id="tipo[6]" value="|6"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">labor</font></font></td><td><input name="tipo[]" type="checkbox" id="tipo[27]" value="|27"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">traffic</font></font></td><td><input name="tipo[]" type="checkbox" id="tipo[7]" value="|7"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">tax</font></font></td>										</tr>
									</tbody></table>
								</div>
							</div>
						</div>
						<div class="row">
														<div class="col-md-12">
								<div class="boxInput">
									<label><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">COMMENTS</font></font></label>
									<textarea placeholder="" name="observacoes" id="pessoas_observacoes" class="input" rows="8" style="visibility: hidden; display: none;"></textarea><div id="cke_pessoas_observacoes" class="cke_113 cke cke_reset cke_chrome cke_editor_pessoas_observacoes cke_ltr cke_browser_webkit" dir="ltr" lang="en" role="application" aria-labelledby="cke_pessoas_observacoes_arialbl"><span id="cke_pessoas_observacoes_arialbl" class="cke_voice_label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Rich Text Editor, people_notes</font></font></span><div class="cke_inner cke_reset" role="presentation"><span id="cke_113_top" class="cke_top cke_reset_all" role="presentation" style="height: auto; user-select: none;"><span id="cke_123" class="cke_voice_label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Editor toolbars</font></font></span><span id="cke_113_toolbox" class="cke_toolbox" role="group" aria-labelledby="cke_123" onmousedown="return false;"><span id="cke_124" class="cke_toolbar" aria-labelledby="cke_124_label" role="toolbar"><span id="cke_124_label" class="cke_voice_label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Paragraph</font></font></span><span class="cke_toolbar_start"></span><span class="cke_toolgroup" role="presentation"><a id="cke_125" class="cke_button cke_button__numberedlist cke_button_off" href="javascript:void('Insert/Remove Numbered List')" title="Insert/Remove Numbered List" tabindex="-1" hidefocus="true" role="button" aria-labelledby="cke_125_label" aria-describedby="cke_125_description" aria-haspopup="false" aria-disabled="false" onkeydown="return CKEDITOR.tools.callFunction(46,event);" onfocus="return CKEDITOR.tools.callFunction(47,event);" onclick="CKEDITOR.tools.callFunction(48,this);return false;"><span class="cke_button_icon cke_button__numberedlist_icon" style="background-image:url('http://localhost:8000/sgr/ckeditor/plugins/icons.png?t=J8Q8');background-position:0 -6380px;background-size:auto;">&nbsp;</span><span id="cke_125_label" class="cke_button_label cke_button__numberedlist_label" aria-hidden="false"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Insert/Remove Numbered List</font></font></span><span id="cke_125_description" class="cke_button_label" aria-hidden="false"></span></a><a id="cke_126" class="cke_button cke_button__bulletedlist cke_button_off" href="javascript:void('Insert/Remove Bulleted List')" title="Insert/Remove Bulleted List" tabindex="-1" hidefocus="true" role="button" aria-labelledby="cke_126_label" aria-describedby="cke_126_description" aria-haspopup="false" aria-disabled="false" onkeydown="return CKEDITOR.tools.callFunction(49,event);" onfocus="return CKEDITOR.tools.callFunction(50,event);" onclick="CKEDITOR.tools.callFunction(51,this);return false;"><span class="cke_button_icon cke_button__bulletedlist_icon" style="background-image:url('http://localhost:8000/sgr/ckeditor/plugins/icons.png?t=J8Q8');background-position:0 -6160px;background-size:auto;">&nbsp;</span><span id="cke_126_label" class="cke_button_label cke_button__bulletedlist_label" aria-hidden="false"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Insert/Remove Bulleted List</font></font></span><span id="cke_126_description" class="cke_button_label" aria-hidden="false"></span></a><span class="cke_toolbar_separator" role="separator"></span><a id="cke_127" class="cke_button cke_button__outdent cke_button_disabled " href="javascript:void('Decrease Indent')" title="Decrease Indent" tabindex="-1" hidefocus="true" role="button" aria-labelledby="cke_127_label" aria-describedby="cke_127_description" aria-haspopup="false" aria-disabled="true" onkeydown="return CKEDITOR.tools.callFunction(52,event);" onfocus="return CKEDITOR.tools.callFunction(53,event);" onclick="CKEDITOR.tools.callFunction(54,this);return false;"><span class="cke_button_icon cke_button__outdent_icon" style="background-image:url('http://localhost:8000/sgr/ckeditor/plugins/icons.png?t=J8Q8');background-position:0 -4840px;background-size:auto;">&nbsp;</span><span id="cke_127_label" class="cke_button_label cke_button__outdent_label" aria-hidden="false"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Decrease Indent</font></font></span><span id="cke_127_description" class="cke_button_label" aria-hidden="false"></span></a><a id="cke_128" class="cke_button cke_button__indent cke_button_off" href="javascript:void('Increase Indent')" title="Increase Indent" tabindex="-1" hidefocus="true" role="button" aria-labelledby="cke_128_label" aria-describedby="cke_128_description" aria-haspopup="false" aria-disabled="false" onkeydown="return CKEDITOR.tools.callFunction(55,event);" onfocus="return CKEDITOR.tools.callFunction(56,event);" onclick="CKEDITOR.tools.callFunction(57,this);return false;"><span class="cke_button_icon cke_button__indent_icon" style="background-image:url('http://localhost:8000/sgr/ckeditor/plugins/icons.png?t=J8Q8');background-position:0 -4620px;background-size:auto;">&nbsp;</span><span id="cke_128_label" class="cke_button_label cke_button__indent_label" aria-hidden="false"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Increase Indent</font></font></span><span id="cke_128_description" class="cke_button_label" aria-hidden="false"></span></a><span class="cke_toolbar_separator" role="separator"></span><a id="cke_129" class="cke_button cke_button__blockquote cke_button_off" href="javascript:void('Block Quote')" title="Block Quote" tabindex="-1" hidefocus="true" role="button" aria-labelledby="cke_129_label" aria-describedby="cke_129_description" aria-haspopup="false" aria-disabled="false" onkeydown="return CKEDITOR.tools.callFunction(58,event);" onfocus="return CKEDITOR.tools.callFunction(59,event);" onclick="CKEDITOR.tools.callFunction(60,this);return false;"><span class="cke_button_icon cke_button__blockquote_icon" style="background-image:url('http://localhost:8000/sgr/ckeditor/plugins/icons.png?t=J8Q8');background-position:0 -990px;background-size:auto;">&nbsp;</span><span id="cke_129_label" class="cke_button_label cke_button__blockquote_label" aria-hidden="false"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Block Quote</font></font></span><span id="cke_129_description" class="cke_button_label" aria-hidden="false"></span></a><a id="cke_130" class="cke_button cke_button__creatediv cke_button_off" href="javascript:void('Create Div Container')" title="Create Div Container" tabindex="-1" hidefocus="true" role="button" aria-labelledby="cke_130_label" aria-describedby="cke_130_description" aria-haspopup="false" aria-disabled="false" onkeydown="return CKEDITOR.tools.callFunction(61,event);" onfocus="return CKEDITOR.tools.callFunction(62,event);" onclick="CKEDITOR.tools.callFunction(63,this);return false;"><span class="cke_button_icon cke_button__creatediv_icon" style="background-image:url('http://localhost:8000/sgr/ckeditor/plugins/icons.png?t=J8Q8');background-position:0 -2310px;background-size:auto;">&nbsp;</span><span id="cke_130_label" class="cke_button_label cke_button__creatediv_label" aria-hidden="false"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Create Div Container</font></font></span><span id="cke_130_description" class="cke_button_label" aria-hidden="false"></span></a><span class="cke_toolbar_separator" role="separator"></span><a id="cke_131" class="cke_button cke_button__justifyleft cke_button_off" href="javascript:void('Align Left')" title="Align Left" tabindex="-1" hidefocus="true" role="button" aria-labelledby="cke_131_label" aria-describedby="cke_131_description" aria-haspopup="false" aria-disabled="false" onkeydown="return CKEDITOR.tools.callFunction(64,event);" onfocus="return CKEDITOR.tools.callFunction(65,event);" onclick="CKEDITOR.tools.callFunction(66,this);return false;"><span class="cke_button_icon cke_button__justifyleft_icon" style="background-image:url('http://localhost:8000/sgr/ckeditor/plugins/icons.png?t=J8Q8');background-position:0 -5280px;background-size:auto;">&nbsp;</span><span id="cke_131_label" class="cke_button_label cke_button__justifyleft_label" aria-hidden="false"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Align Left</font></font></span><span id="cke_131_description" class="cke_button_label" aria-hidden="false"></span></a><a id="cke_132" class="cke_button cke_button__justifycenter cke_button_off" href="javascript:void('Center')" title="Center" tabindex="-1" hidefocus="true" role="button" aria-labelledby="cke_132_label" aria-describedby="cke_132_description" aria-haspopup="false" aria-disabled="false" onkeydown="return CKEDITOR.tools.callFunction(67,event);" onfocus="return CKEDITOR.tools.callFunction(68,event);" onclick="CKEDITOR.tools.callFunction(69,this);return false;"><span class="cke_button_icon cke_button__justifycenter_icon" style="background-image:url('http://localhost:8000/sgr/ckeditor/plugins/icons.png?t=J8Q8');background-position:0 -5170px;background-size:auto;">&nbsp;</span><span id="cke_132_label" class="cke_button_label cke_button__justifycenter_label" aria-hidden="false"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Center</font></font></span><span id="cke_132_description" class="cke_button_label" aria-hidden="false"></span></a><a id="cke_133" class="cke_button cke_button__justifyright cke_button_off" href="javascript:void('Align Right')" title="Align Right" tabindex="-1" hidefocus="true" role="button" aria-labelledby="cke_133_label" aria-describedby="cke_133_description" aria-haspopup="false" aria-disabled="false" onkeydown="return CKEDITOR.tools.callFunction(70,event);" onfocus="return CKEDITOR.tools.callFunction(71,event);" onclick="CKEDITOR.tools.callFunction(72,this);return false;"><span class="cke_button_icon cke_button__justifyright_icon" style="background-image:url('http://localhost:8000/sgr/ckeditor/plugins/icons.png?t=J8Q8');background-position:0 -5390px;background-size:auto;">&nbsp;</span><span id="cke_133_label" class="cke_button_label cke_button__justifyright_label" aria-hidden="false"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Align Right</font></font></span><span id="cke_133_description" class="cke_button_label" aria-hidden="false"></span></a><a id="cke_134" class="cke_button cke_button__justifyblock cke_button_off" href="javascript:void('Justify')" title="Justify" tabindex="-1" hidefocus="true" role="button" aria-labelledby="cke_134_label" aria-describedby="cke_134_description" aria-haspopup="false" aria-disabled="false" onkeydown="return CKEDITOR.tools.callFunction(73,event);" onfocus="return CKEDITOR.tools.callFunction(74,event);" onclick="CKEDITOR.tools.callFunction(75,this);return false;"><span class="cke_button_icon cke_button__justifyblock_icon" style="background-image:url('http://localhost:8000/sgr/ckeditor/plugins/icons.png?t=J8Q8');background-position:0 -5060px;background-size:auto;">&nbsp;</span><span id="cke_134_label" class="cke_button_label cke_button__justifyblock_label" aria-hidden="false"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Justify</font></font></span><span id="cke_134_description" class="cke_button_label" aria-hidden="false"></span></a></span><span class="cke_toolbar_end"></span></span><span id="cke_135" class="cke_toolbar cke_toolbar_last" aria-labelledby="cke_135_label" role="toolbar"><span id="cke_135_label" class="cke_voice_label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Basic Styles</font></font></span><span class="cke_toolbar_start"></span><span class="cke_toolgroup" role="presentation"><a id="cke_136" class="cke_button cke_button__bold cke_button_off" href="javascript:void('Bold')" title="Bold (Ctrl+B)" tabindex="-1" hidefocus="true" role="button" aria-labelledby="cke_136_label" aria-describedby="cke_136_description" aria-haspopup="false" aria-disabled="false" onkeydown="return CKEDITOR.tools.callFunction(76,event);" onfocus="return CKEDITOR.tools.callFunction(77,event);" onclick="CKEDITOR.tools.callFunction(78,this);return false;"><span class="cke_button_icon cke_button__bold_icon" style="background-image:url('http://localhost:8000/sgr/ckeditor/plugins/icons.png?t=J8Q8');background-position:0 -110px;background-size:auto;">&nbsp;</span><span id="cke_136_label" class="cke_button_label cke_button__bold_label" aria-hidden="false"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Bold</font></font></span><span id="cke_136_description" class="cke_button_label" aria-hidden="false"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Keyboard shortcut Ctrl+B</font></font></span></a><a id="cke_137" class="cke_button cke_button__italic cke_button_off" href="javascript:void('Italic')" title="Italic (Ctrl+I)" tabindex="-1" hidefocus="true" role="button" aria-labelledby="cke_137_label" aria-describedby="cke_137_description" aria-haspopup="false" aria-disabled="false" onkeydown="return CKEDITOR.tools.callFunction(79,event);" onfocus="return CKEDITOR.tools.callFunction(80,event);" onclick="CKEDITOR.tools.callFunction(81,this);return false;"><span class="cke_button_icon cke_button__italic_icon" style="background-image:url('http://localhost:8000/sgr/ckeditor/plugins/icons.png?t=J8Q8');background-position:0 -220px;background-size:auto;">&nbsp;</span><span id="cke_137_label" class="cke_button_label cke_button__italic_label" aria-hidden="false"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">italic</font></font></span><span id="cke_137_description" class="cke_button_label" aria-hidden="false"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Keyboard shortcut Ctrl+I</font></font></span></a><a id="cke_138" class="cke_button cke_button__underline cke_button_off" href="javascript:void('Underline')" title="Underline (Ctrl+U)" tabindex="-1" hidefocus="true" role="button" aria-labelledby="cke_138_label" aria-describedby="cke_138_description" aria-haspopup="false" aria-disabled="false" onkeydown="return CKEDITOR.tools.callFunction(82,event);" onfocus="return CKEDITOR.tools.callFunction(83,event);" onclick="CKEDITOR.tools.callFunction(84,this);return false;"><span class="cke_button_icon cke_button__underline_icon" style="background-image:url('http://localhost:8000/sgr/ckeditor/plugins/icons.png?t=J8Q8');background-position:0 -660px;background-size:auto;">&nbsp;</span><span id="cke_138_label" class="cke_button_label cke_button__underline_label" aria-hidden="false"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Underline</font></font></span><span id="cke_138_description" class="cke_button_label" aria-hidden="false"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Keyboard shortcut Ctrl+U</font></font></span></a></span><span class="cke_toolbar_end"></span></span></span></span><div id="cke_113_contents" class="cke_contents cke_reset" role="presentation" style="height: 212px;"><span id="cke_143" class="cke_voice_label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Press ALT 0 for help</font></font></span><iframe src="" frameborder="0" class="cke_wysiwyg_frame cke_reset" title="Rich Text Editor, people_notes" aria-describedby="cke_143" tabindex="0" allowtransparency="true" style="width: 100%; height: 100%;"></iframe></div><span id="cke_113_bottom" class="cke_bottom cke_reset_all" role="presentation" style="user-select: none;"><span id="cke_113_resizer" class="cke_resizer cke_resizer_vertical cke_resizer_ltr" title="resize" onmousedown="CKEDITOR.tools.callFunction(44, event)"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">◢</font></font></span><span id="cke_113_path_label" class="cke_voice_label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Elements path</font></font></span><span id="cke_113_path" class="cke_path" role="group" aria-labelledby="cke_113_path_label"><span class="cke_path_empty">&nbsp;</span></span></span></div></div>
								</div>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-12 col--btn-more">
							<a class="boxJanela__item-interaction_pessoas" id="boxJanela__item-interaction_pessoas" title="Search Type"><i class="fa fa-minus-circle" aria-hidden="true"></i>  Menos Informações</a>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-md-12 boxJanela--col-footer">
						<input type="hidden" name="f[action]" value="gravar">
														<a onclick="altera_pessoa('1176347','conclude');" name="btgravar" class="btn btn--medium" value="Salvar">
									<i class="fa fa-floppy-o" aria-hidden="true"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">To save
								</font></font></a>
																<a onclick="altera_pessoa('1176347','leave');" class="btn btn--medium" value="Salvar e Sair">
									<i class="fa fa-floppy-o" aria-hidden="true"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Save and Exit
								</font></font></a>
													<a type="button" name="voltar" class="btn btn--medium btn--exit" id="voltar" value="Cancelar" onclick="reset_content_pessoa();desativa_modal(CADASTRO_pessoas);limpa_edited_pessoas(); verifica_nova_pessoa(1176347);">
							<i class="fa fa-times-circle" aria-hidden="true"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> Cancel
						</font></font></a>
						<span style="color:#ff0000;font-weight:700;font-size: 10px;vertical-align: bottom;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">* REQUIRED FIELDS</font></font></span>
					</div>
				</div>
			</form>
      </div>
  </div>


        <?php echo $__env->make('layouts.footers.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script src="<?php echo e(asset('argon')); ?>/vendor/chart.js/dist/Chart.min.js"></script>
    <script src="<?php echo e(asset('argon')); ?>/vendor/chart.js/dist/Chart.extension.js"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bader/Bureau/PFE's/EasyJur/resources/views/people/index.blade.php ENDPATH**/ ?>