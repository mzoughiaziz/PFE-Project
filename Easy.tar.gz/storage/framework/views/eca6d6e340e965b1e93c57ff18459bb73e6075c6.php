<?php $__env->startSection('content'); ?>
    <div class="header bg-gradient-primary pb-8 pt-5 pt-md-8">

    </div>
    <div class="container-fluid mt--7">
        <div class="row">
            <div class="col">
                <div class="card shadow">
                    <div class="card-header border-0">
                        <div class="row align-items-center">
                            <div class="col-8">
                                <h3 class="mb-0">Advisory Projects</h3>
                            </div>
                            <div class="col-4 text-right">
                                
                                <button type="button" class="btn btn-sm btn-primary" data-toggle="modal"
                                    data-target="#modal-form">
                                    Create new
                                </button>
                            </div>
                        </div>
                    </div>

                    <div class="col-12">
                    </div>

                    <div class="table-responsive">
                        <table class="table align-items-center table-flush">
                            <thead class="thead-light">
                                <tr>
                                    <th scope="col">Id</th>
                                    <th scope="col">Name</th>
                                    <th scope="col">Description </th>
                                    <th scope="col">Associate name</th>
                                    <th scope="col">Client name</th>
                                    <th scope="col">Status </th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td> <?php echo e($project->id); ?> </td>
                                        <td> <?php echo e($project->name); ?> </td>
                                        <td> <?php echo e($project->descreption); ?> </td>
                                        <td> <?php echo e($project->user_id); ?> </td>
                                        <td> <?php echo e($project->client_id); ?> </td>
                                        <td> <?php echo e($project->Step); ?> 
                                            <span class="badge badge-dot mr-4">
                                              <i class="bg-success"></i>
                                              <span class="status">completed</span>
                                            </span>
                                        </td>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>

                </div>
            </div>
        </div>
    </div>
    </div>

    <div class="col-md-4">

        <div class="modal fade" id="modal-form" tabindex="-1" role="dialog" aria-labelledby="modal-form" aria-hidden="true">
            <div class="modal-dialog modal- modal-dialog-centered modal-lg" role="document">
                <div class="modal-content">

                    <div class="modal-body p-0">
                        

                        <div class="card bg-secondary border-0 mb-0">

                            <div class="card-body px-lg-5 py-lg-5">
                                <div class="text-center text-muted mb-4">
                                    <h2>Create new project</h2>
                                </div>
                                <form role="form">
                                    <div class="mb-3">
                                        <div class="input-group">
                                            <input class="form-control" placeholder="Project name" type="text">
                                        </div>
                                    </div>

                                    <div class="mb-3">
                                        <div class="input-group">
                                            <select class="form-control" id="">
                                                <option value="Stage">Status</option>
                                                <option value="todo">To do</option>
                                                <option value="doing">Doing</option>
                                                <option value="done">Done</option>
                                            </select>
                                            <input class="form-control" placeholder="Client name" type="text">
                                            <input class="form-control" placeholder="User name" type="text">
                                        </div>
                                    </div>

                                    <div class="mb-3">
                                        <div class="input-group">
                                            <input class="form-control" placeholder="Description" type="text">
                                        </div>
                                    </div>


                                    <div class="text-center">
                                        <button type="button" class="btn btn-primary ">Create</button>
                                    </div>

                                </form>
                            </div>
                        </div>


                        

                    <?php $__env->stopSection(); ?>

                    <?php $__env->startPush('js'); ?>
                        <script src="<?php echo e(asset('argon')); ?>/vendor/chart.js/dist/Chart.min.js"></script>
                        <script src="<?php echo e(asset('argon')); ?>/vendor/chart.js/dist/Chart.extension.js"></script>
                    <?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bader/Bureau/PFE's/EasyJur/resources/views/project/index.blade.php ENDPATH**/ ?>